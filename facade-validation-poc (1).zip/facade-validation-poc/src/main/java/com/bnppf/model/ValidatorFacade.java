package com.bnppf.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

@Component
public class ValidatorFacade {
    private static final Logger log = LoggerFactory.getLogger(ValidatorFacade.class);

    private Validator getValidator(){
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        return factory.getValidator();
    }

    public void validate(BusinessRequest<RequestResource> businessRequest){
        Set<ConstraintViolation<RequestResource>> violations = getValidator().validate(businessRequest.getRequest());

        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (ConstraintViolation<RequestResource> violation : violations) {
                sb.append("violation message = "+violation.getMessage()).append("\n");
            }
            throw new IllegalArgumentException("request validation failed: \n" + sb);
        }

        log.info("control facade successfully");
    }
}
