package com.bnppf.model;

public enum TypeEvent {
    ACCESS_SYSTEM("ACCESS_SYSTEM");

    private String event;

    TypeEvent(String event){
        this.event = event;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public static boolean isValid(String type) {
        for (TypeEvent typeEvent : TypeEvent.values()) {
            if (typeEvent.name().equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }
}
