package com.bnppf.model;

public enum AuthMode {
    LOGIN_PWD("LOGIN_PWD");

    private String mode;

    AuthMode(String mode){
        this.mode = mode;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public static boolean isValid(String mode) {
        for (AuthMode authMode : AuthMode.values()) {
            if (authMode.name().equalsIgnoreCase(mode)) {
                return true;
            }
        }
        return false;
    }
}
