package com.bnppf.model;

import javax.validation.constraints.AssertTrue;

@CoherenceConstraint()
public class RequestResource {

    private String authMode;
    private String typeEvent;

    public String getAuthMode() {
        return authMode;
    }

    public void setAuthMode(String authMode) {
        this.authMode = authMode;
    }

    public String getTypeEvent() {
        return typeEvent;
    }

    public void setTypeEvent(String typeEvent) {
        this.typeEvent = typeEvent;
    }

    @AssertTrue()
    public boolean isValid(){
       return AuthMode.isValid(getAuthMode()) &&
                TypeEvent.isValid(getTypeEvent());
    }
}
