package com.erreur.demo;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "errors")
public class ErrorProperties {

    private List<ErrorMapping> errorList;

    public List<ErrorMapping> getErrorList() {
        return errorList;
    }

    public void setErrorList(List<ErrorMapping> errorList) {
        this.errorList = errorList;
    }

    public static class ErrorMapping {
        private ErrorCode code;
        private String message;

        public ErrorCode getCode() {
            return code;
        }

        public void setCode(ErrorCode code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
