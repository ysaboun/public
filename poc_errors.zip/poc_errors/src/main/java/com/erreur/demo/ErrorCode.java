package com.erreur.demo;

public enum ErrorCode {
    WCAUT001,
    WCAUT002,
    WCAUT003
}

