package com.erreur.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErrorService {

    private final ErrorProperties errorProperties;

    @Autowired
    public ErrorService(ErrorProperties errorProperties) {
        this.errorProperties = errorProperties;
    }

    public void printErrors() {
        List<ErrorProperties.ErrorMapping> errorList = errorProperties.getErrorList();
        for (ErrorProperties.ErrorMapping error : errorList) {
            System.out.println("Code: " + error.getCode() + ", Message: " + error.getMessage());
        }
    }

    public String getErrorMessage(ErrorCode errorCode) {
        return errorProperties.getErrorList().stream()
                .filter(error -> error.getCode() == errorCode)
                .map(ErrorProperties.ErrorMapping::getMessage)
                .findFirst()
                .orElse("Unknown error");
    }

}
