package com.erreur.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class DemoApplicationTests {
	private final ErrorService errorService;

	@Autowired
	public DemoApplicationTests(ErrorService errorService) {
		this.errorService = errorService;
	}

	@Test
	void contextLoads() {
	}

	@Test
	void testCode(){
		assertEquals(errorService.getErrorMessage(ErrorCode.WCAUT001),
				"message WCAUT001");
	}

}
