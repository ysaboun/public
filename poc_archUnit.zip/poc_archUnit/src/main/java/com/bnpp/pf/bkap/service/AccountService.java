package com.bnpp.pf.bkap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class AccountService {
    private AccountDataSource accountDataSource;

    @Autowired
    public AccountService(AccountDataSource accountDataSource) {
        this.accountDataSource = accountDataSource;
    }

    public Collection<Account> getAccount(){
        return accountDataSource.fetchAccounts();
    }
}
