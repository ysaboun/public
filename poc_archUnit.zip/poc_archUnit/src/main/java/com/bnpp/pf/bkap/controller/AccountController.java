package com.bnpp.pf.bkap.controller;

import com.bnpp.pf.bkap.service.AccountService;
import com.bnpp.pf.bkap.service.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/v1")
public class AccountController {
    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping(path= "/accounts")
    public Collection<Account> getAccounts() {
        return accountService.getAccount();
    }
}

