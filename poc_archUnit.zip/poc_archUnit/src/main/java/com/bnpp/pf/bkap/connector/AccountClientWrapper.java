package com.bnpp.pf.bkap.connector;

import com.bnpp.pf.bkap.service.Account;
import com.bnpp.pf.bkap.service.AccountDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Component
public class AccountClientWrapper implements AccountDataSource {

    private final AccountClient accountClient;

    @Autowired
    public AccountClientWrapper(AccountClient accountClient) {
        this.accountClient = accountClient;
    }

    @Override
    public Collection<Account> fetchAccounts() {
        try {
            return accountClient.fetchAccounts();
        }catch (final Exception e){
            throw new RuntimeException();
        }
    }
}
