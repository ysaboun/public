package com.bnpp.pf.bkap.service;

import java.util.Collection;

public interface AccountDataSource {
    Collection<Account> fetchAccounts();
}
