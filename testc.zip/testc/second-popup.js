chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.inputValue) {
        document.getElementById('output').textContent = request.inputValue;
    }
});
