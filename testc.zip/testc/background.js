chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['popup.js']
  });
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.inputValue) {
        chrome.windows.create({
            url: 'second-popup.html',
            type: 'popup',
            width: 250,
            height: 150,
            left: Math.floor((screen.width - 250) / 2),
            top: Math.floor((screen.height - 150) / 2)
        });
    }
});