// Verifie si la popup existe deja pour eviter la duplication
if (!document.getElementById('custom-popup')) {
  // Creation de la div pour la popup
  const popup = document.createElement('div');
  popup.id = 'custom-popup';
  popup.innerHTML = `
    <div class="small-12 medium-10 large-10 xxlarge-6 credit-simulator white">
                 <p class="text-subtitle" for="credit-simulator-value--sidebar">
                     <b>Un projet  Trouvez votre pret </b>
                 </p>
                 <div class="credit-simulator__footer hide-for-small-only">
                 </div>
                 <div class="credit-simulator__form grid-x">
                     <div class="credit-simulator__amount cell small-12 medium-7 large-7 xxlarge-7">
                         <input id="credit-simulator-value--slider" name="amount" type="text" placeholder="0" inputmode="numeric" autocomplete="off" aria-required="true" aria-invalid="false">
                         <span class="credit-simulator__amount__text error text-small hide" aria-hidden="true">Le montant doit etre superieur a 500</span>
                         <span class="credit-simulator__amount__text text-small" aria-hidden="true">Saisissez un montant, a partir de 500</span>
                     </div>
                     <a id="credit-simulator-button--slider" class="credit-simulator__button button cell auto active" href="/fr/simulateur?project=&amp;subProject=" role="button" aria-label="Ouvrir Simuler votre credit">
                         Simuler votre credit
                     </a>
                 </div>
             </div>
  `;

  // Ajoute la popup au corps du document
  document.body.appendChild(popup);

  // Styles pour la popup via JS en plus de popup.css
  popup.style.position = 'fixed';
  popup.style.bottom = '0';
  popup.style.left = '0';
  popup.style.width = '100%';
  popup.style.backgroundColor = 'green';
  popup.style.color = 'black';
  popup.style.padding = '10px';
  popup.style.textAlign = 'center';
  popup.style.zIndex = '9999';
}