// Verifier si la popup existe deja
if (!document.getElementById('custom-popup')) {
    // Creer une div pour la popup
    let popup = document.createElement('div');
    popup.id = 'custom-popup';
    popup.style.position = 'fixed';
    popup.style.bottom = '0';
    popup.style.left = '50%';
    popup.style.transform = 'translateX(-50%)';
    popup.style.width = '300px';
    popup.style.backgroundColor = '#f1f1f1';
    popup.style.padding = '20px';
    popup.style.border = '1px solid #ccc';
    popup.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    popup.style.zIndex = '9999';
    popup.style.borderRadius = '10px';
    popup.style.textAlign = 'center';

    // Contenu de la popup
    popup.innerHTML = `
        <h3 style="margin-top: 0;">Bienvenue !</h3>
        <p>Visitez notre site partenaire.</p>
        <button id="visit-cafineo" style="padding: 10px 15px; background-color: #4CAF50; color: white; border: none; cursor: pointer; border-radius: 5px;">Aller sur Cafineo</button>
        <button id="close-popup" style="padding: 5px 10px; background-color: red; color: white; border: none; cursor: pointer; border-radius: 5px; margin-top: 10px;">Fermer</button>
    `;

    // Ajouter la popup au corps de la page
    document.body.appendChild(popup);

    // Fermer la popup
    document.getElementById('close-popup').addEventListener('click', () => {
        popup.remove();
    });

    // Bouton pour aller sur Cafineo
    document.getElementById('visit-cafineo').addEventListener('click', () => {
        window.location.href = 'https://www.cafineo.fr';
    });
}
