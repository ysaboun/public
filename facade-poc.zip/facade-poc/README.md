- fixme config/filter.yml
- adr gestion erreur : codification ffrrrnnn  facaderoutenumero
- resilience ? circuit breaker
- basic auth pattern ?
- log lib ?
- swagger ui ?
- vault secret facade ?
- sonar : complexity cyclomatique;...?


- facade-archi (archiunit) : OK 
- control facade lib: facade-model ?  ok


# 2. Microservices structure
001-micro-services-structure.md

We need to follow a "minimal" common structure for all microservices in order
to guarantee an easier maintenance I and to facilitate switching between microservices.
We need to structure code to avoid binding microservice logic to external services representations.
use a domain-driven-design approach to structure every microservice

We will use the following package structure:
`com.bnppf. {micro_service_name}
application: contains microservice classes used to expose services
   - mapper
   - model
domain: package contains all microservices logic and domain classes
     - model
infrastructure: contains microservices classes used to call external services
   - mapper 
   - model
service: conatins classes to use to orchestrate calls between infra, domain and application package

application <----> services -> provider
                     |
                      > domain



### Application package,
