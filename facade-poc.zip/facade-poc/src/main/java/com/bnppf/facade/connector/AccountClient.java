package com.bnppf.facade.connector;


import com.bnppf.facade.service.Account;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


@Component
public class AccountClient {
  public Collection<Account> fetchAccounts(){
      List<Account> accountList = new ArrayList<>();
      Account account = new Account();
      account.setAccountId("41004388182100");
      accountList.add(account);
      return accountList;
  }
}
