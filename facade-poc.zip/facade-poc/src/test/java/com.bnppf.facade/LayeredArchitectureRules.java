package com.bnppf.facade;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

import static com.tngtech.archunit.core.domain.JavaClass.Predicates.resideInAPackage;
import static com.tngtech.archunit.library.Architectures.layeredArchitecture;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

public final class LayeredArchitectureRules {

    private static final String CONTROLLERS_LAYER = "Controllers";
    private static final String SERVICES_LAYER = "Services";
    private static final String CONNECTORS_LAYER = "Connector";

    @ArchTest
    public static ArchRule service_layer_dependencies_are_respected = layeredArchitecture()
            .as("Layer dependencies are respected")

            .layer(CONTROLLERS_LAYER).definedBy("com.bnppf.*.controller..")
            .layer(SERVICES_LAYER).definedBy("com.bnppf.*.service..")
            .layer(CONNECTORS_LAYER).definedBy("com.bnppf.*.connector..")

            .whereLayer(CONTROLLERS_LAYER).mayNotBeAccessedByAnyLayer()
            .whereLayer(SERVICES_LAYER).mayOnlyBeAccessedByLayers(CONTROLLERS_LAYER,CONNECTORS_LAYER)
            .whereLayer(CONNECTORS_LAYER).mayNotBeAccessedByAnyLayer()

            .ignoreDependency(resideInAPackage("..stage.."), DescribedPredicate.alwaysTrue())

            .because("Services layer should concentrate business logic and not be infected by interfaces with external systems");


    @ArchTest
    public static ArchRule connectors_do_not_depend_on_one_another = slices()
            .matching("com.bnppf.*.(connector).(*)").namingSlices("$1 '$2'")
            .as("Connectors should not depend on one another")
            .should().notDependOnEachOther()
            .because("Connectors are adapters that isolate dependencies towards external systems");

    @ArchTest
    public static ArchRule services_do_not_depend_on_one_another = slices()
            .matching("com.bnppf.*.(service).(*)").namingSlices("$1 '$2'")
            .as("Services should not depend on one another")
            .should().notDependOnEachOther()
            .because("Services should be split so that they do not depend on one another");
}
