package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.*;
import com.bnppf.model.AuthMode;
import com.bnppf.model.RequestResource;
import com.bnppf.model.TypeEvent;
import com.google.gson.Gson;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

/**
 * class to validate the request:
 * signature verification, required headers
 *
 * on successful return headers list
 */
@Component
public class RequestValidator {

    private static final Logger log = LoggerFactory.getLogger(RequestValidator.class);

    @Autowired
    FilterConfiguration configuration;

    /**
     * get all headers from request
     */

    public Map<String , Map<String, String>> getHeaders(HttpServletRequest request){
       Map<String, Map<String, String>> alls = new HashMap<>();
        Enumeration<String> headerNames = request.getHeaderNames();
        Map<String, String> allHeaders = new HashMap<>();

        while (headerNames.hasMoreElements()){
            String name = headerNames.nextElement();
            allHeaders.put(name.toLowerCase(), request.getHeader((name)));
        }

        alls.put("all", allHeaders);
        for(String header:allHeaders.keySet()){
            log.info(String.format("request has %s header with value: %s", header, allHeaders.get(header)));
        }
        Map<String , String> matchHeaders = new HashMap<>();
        for(String header: allHeaders.keySet()){
            if(configuration.getRequiredHeaders().contains(header)){
                matchHeaders.put(header.toLowerCase(), request.getHeader(header));
            }
        }
        for(String header: matchHeaders.keySet()){
            log.info(String.format("store %s header with value: %s", header, matchHeaders.get(header)));
        }

        alls.put("match", matchHeaders);
        return alls;
    }

    /**
     * determine the request type
     * -1 uri d'ont match, -2 uri match but method is not allowed
     */
    private int requestTypeDetermination(HttpServletRequest request){
        String uri = request.getRequestURI();
        for (int i=0; i < configuration.getAuthorizedUri().size(); i++){
            Pattern uriPattern = Pattern.compile(configuration.getAuthorizedUri().get(i).getUriRegexp());
            if(uriPattern.matcher(uri).matches()){
                return i;
            }
        }
        return -1;
    }

    /**
     * request validation
     */
    public ValidateResponse validate(ServletRequest request) throws FilterException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;

        String method = httpServletRequest.getMethod();
        String body = null;

        try {
            /**
             * 1.extraction
             */
            log.info("1.1 extract headers and validate path");

            //1.1 extract headers and validate path
            Map<String, Map<String, String >> mapHeaders = getHeaders(httpServletRequest);
            Map<String, String> allHeaders = mapHeaders.get("all");
            Map<String, String> headers = mapHeaders.get("match");

            Map<String, String> requestInfoMap = resolveRequestInfo(httpServletRequest,
                    configuration.getFilterSecurity().getHeaderOriginHost(),
                    configuration.getFilterSecurity().getHeaderOriginPath());

            ValidateResponse validateResponse = new ValidateResponse();
            boolean shouldHaveBody = "POST".equals(method)|| "PUT".equals(method);
            boolean isTrustedRequest = httpServletRequest.getRequestURI().startsWith(configuration.getTrustedPath());

            String authorizationToken;

            /**
             * Handle trusted URL. Pass through filter. No audit are required because audit log
             * has already been store in backend-services.
             * request headers should not contains authorization or certificate header
             * (only supplied when request comes from wso2).
             */
            log.info("isTrustedRequest"+isTrustedRequest);
            if(isTrustedRequest){
                body = getBodyString(httpServletRequest);
                log.info("requestInfoMap"+ requestInfoMap);
                return getValidateResponse(httpServletRequest, body);
            }else {
                authorizationToken= null;//extractToken(httpServletRequest.getHeader(configuration.getFilterSecurity().getAuthorizationHeader()))
            }

            //1.2. body
            log.info("1.2. body");
            if(shouldHaveBody){
                body = getBodyString(httpServletRequest);
                System.out.println(String.format("request body is %s", body));
            }

            /**
             * 2.1 controls
             *  verify request type
             *  if we are here, it's the request must be handled to so an
             *  authorizationUri object must be found
             */

            log.info("2.1 controls verify request type");

            AuthorizedUri authorizedUri;
            int pos = requestTypeDetermination(httpServletRequest);
            if(pos == -1){
                log.info(String.format("URI invalid or method is not allowed %s", method));
              throw new FilterException( "", Constant.ERRORS.STATUS_405);
            }else {
                authorizedUri = configuration.getAuthorizedUri().get(pos);
                log.info(String.format("authorizedUri %s", authorizedUri));
            }

            //2.2 verify all required header are present
            log.info("2.2 verify all required header are present");
            log.info(String.format("headers in request : %d", headers.size()));
            log.info(String.format("required headers : %d", configuration.getRequiredHeaders().size()));

            if(headers.size() != configuration.getRequiredHeaders().size()){
                List<String> missing = new ArrayList<>(configuration.getRequiredHeaders());
                missing.removeAll(headers.keySet());
                String  errorMessage = String.format("missing headers : %s", missing.toString());
                log.info("errorMessage: "+errorMessage);
                throw  new FilterException("", Constant.ERRORS.STATUS_405);
            }

            // 2.3 verify siganture
            log.info("2.3 verify siganture");

            //2.4 verify body presence if required
            log.info("2.4 verify body presence if required");
            if(shouldHaveBody && body.isBlank()){
                log.info("missing body");
                throw  new FilterException("", Constant.ERRORS.STATUS_400);
            }

            //2.5. verify body digest
            log.info("2.5. verify body digest");
            /*if(shouldHaveBody){
                if(allHeaders.get("digest") !=null){
                    String receiveDigest = allHeaders.get("digest");
                    String digest = null;//String.format("SHA-256=%s", Base64.getEncoder().encodeToString(DigestUtils.sha256(body)));

                    if(!receiveDigest.equals(digest)){
                        System.out.println(String.format("received digest header is %s. Computed is %s", receiveDigest, digest));
                        //log error
                        throw  new FilterException("", Constant.ERRORS.STATUS_400);
                    }else {
                        System.out.println("digest match");
                    }
                }else{
                    System.out.println("missing digest header");
                    throw  new FilterException("", Constant.ERRORS.STATUS_400);
                }
            }*/

            //2.6 decode jwt if any
            log.info("2.6 decode jwt if any");
            // store request if necessary
            ApiRequest apiRequest = new ApiRequest();
           // apiRequest.setHeaders(getHeaderToStrore(allHeaders, headers));
            apiRequest.setRequestId(request.getRequestId());
            apiRequest.setRequestType(APisRequest.REQUEST_TYPES.valueOf(authorizedUri.getType()).type());
            if(body!=null && body.length() >0){
                log.info("body is:"+ body);
                apiRequest.setRequest(getRequestObjectFromJson(body, APisRequest.REQUEST_TYPES.valueOf(authorizedUri.getType()).type()));
            }
            apiRequest.setRequestUri(requestInfoMap.get("path"));
            //apiRequest.setOriginUrl(requestInfoMap.get("origin"));
            //apiRequest.setBaseURL(requestInfoMap.get(requesturi));
            apiRequest.setToken(authorizationToken);
            validateResponse.setUriDescription(authorizedUri);
            validateResponse.setApiRequest(apiRequest);
            validateResponse.setDoContinue(false);

            return validateResponse;
        }catch (IOException ex){
            log.info(String.format("error request body: %s", ex.getMessage()));
            throw  new FilterException("", Constant.ERRORS.STATUS_400);
        }
    }

    private Object getRequestObjectFromJson(String body, String type) {
        if(APisRequest.REQUEST_TYPES.EVENT_REQUEST.type().equals(type)){
            return new Gson().fromJson(body, RequestResource.class);
        } else return new Gson().fromJson(body, ApiNone.class);
    }

    private String getBodyString(HttpServletRequest request) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader reader = request.getReader();
        char[] buffer = new char[1024];
        int len;
        while ((len=reader.read(buffer, 0, buffer.length)) != -1){
            stringBuilder.append(buffer, 0, len);
        }
        return stringBuilder.toString();
    }

    /**
     * resolve api path and vesrion (suppose https only)
     *
     */
    private Map<String, String> resolveRequestInfo(HttpServletRequest request, String  hostHeaderName,
                                                   String pathHeaderName){
        Map<String , String > map = new HashMap<>();
        String servletPath = request.getServletPath();
        map.put("version", null);
        map.put("querystring", request.getQueryString());
        //in case of trusted request, header x-forwarded are not supplied
        if(request.getHeader(hostHeaderName) != null){
            String host = request.getHeader(hostHeaderName).split(",")[0].trim();
            map.put("publichost", host);
            String url = "https://" + host + request.getHeader(pathHeaderName);
            map.put("origin", url);
            //String path = getPathFromUrl(url);
            map.put("path", null);//path
            //map.put("version", getVersionFromPath(url, servletPath));
            map.put("requesturi", url.replaceAll(servletPath, ""));
        }else{
            map.put("publichost", null);
            map.put("origin", null);
            map.put("path", null);
            map.put("requesturi", null);
        }
        //debug
        log.info("resolveRequestInfo output map is" + map.toString());
        return map;
    }

    private ValidateResponse getValidateResponse(ServletRequest request, String body){

        ValidateResponse validateResponse = new ValidateResponse();
        AbstractApiRequest abstractApiRequest = new Gson().fromJson(body, AbstractApiRequest.class);

        log.info("Request type:"+abstractApiRequest.getRequestType());
        if(APisRequest.REQUEST_TYPES.EVENT_REQUEST.type().equals(abstractApiRequest.getRequestType())){

        }
        /*ApiRequest<RequestResource> apiRequest = new ObjectMapper().
                registerModule(new JavaTimeModule()).disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                        .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
                                .readValue(bodyString, new TypeReference<ApiRequest<RequestResource>>(){});*/
        ApiRequest<RequestResource> apiRequest = new ApiRequest<>();
        apiRequest.setRequestId("requestId");
        RequestResource requestResource = new RequestResource();
        requestResource.setAuthMode(AuthMode.LOGIN_PWD.name());
        requestResource.setTypeEvent(TypeEvent.ACCESS_SYSTEM.name());
        apiRequest.setRequest(requestResource);
        request.setAttribute("api-request", apiRequest);
        validateResponse.setDoContinue(true);

        return validateResponse;
    }
}
