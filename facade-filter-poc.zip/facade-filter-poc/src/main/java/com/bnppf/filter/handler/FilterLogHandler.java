package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class FilterLogHandler {

    private static final Logger log = LoggerFactory.getLogger(FilterLogHandler.class);

    @Autowired
    private FilterConfiguration configuration;

    public void prepareLogging(HttpServletRequest request) throws Exception {
        String requestId = request.getHeader(configuration.getFilterSecurity().getHeaderRequestId());
        if( requestId == null) throw new Exception("No request id header !");

        MDC.put("requestId", requestId);
    }
}
