package com.bnppf.filter.model;

import com.bnppf.model.RequestResource;

import java.util.Map;

public class APisRequest {
    /**
     * request identifier to identify the request handler
     * more secure and less CPU consummer than introspection
     * Key type is used in filter to identify request types
     *
     */

    public enum REQUEST_TYPES{
        ACCOUNTS_REQUEST("ACT", ApiNone.class),
        EVENT_REQUEST("EVT", RequestResource.class);
       private final String type;
       private final Class<?> clazz;

       REQUEST_TYPES(String type, Class<?> clazz){
           this.type = type;
           this.clazz = clazz;
       }

       public String type(){
           return this.type;
       }

        public Class<?> getClazz() {
            return clazz;
        }

        public static Class<?> getClassByType(String key) {
            for (REQUEST_TYPES entry : REQUEST_TYPES.values()) {
                if (entry.type.equals(key)) {
                    return entry.getClazz();
                }
            }
            throw new IllegalArgumentException("No class found for key: " + key);
        }
    }

    /**
     * request URI
     */
    private String requestUri;

    /**
     * request id
     */
    private String requestId;


    /**
     * request type
     */
    private String requestType;

    private String body;

    /**
     * request headers list
     */
    private Map<String, String> headers;

    /**
     * access token
     */
    private String token;

}
