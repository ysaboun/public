package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.ArgumentsList;
import com.bnppf.filter.model.ResponseHandlerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * class to handle response
 */

@Component
public class ResponseHandler {
    private static final Logger log = LoggerFactory.getLogger(ResponseHandler.class);

    private Map<String, Function<ArgumentsList, ResponseHandlerResponse>> handlers = new HashMap<>();

    public Map<String, Function<ArgumentsList, ResponseHandlerResponse>> getHandlers() {
        return handlers;
    }

    @Autowired
    FilterConfiguration configuration;

    public ResponseHandlerResponse handleAccountsResponse(ArgumentsList arguments){
        log.info(String.format("handleAccountsResponse>>> %s", arguments.getApiRequest().getRequestId()));
        ResponseHandlerResponse handlerResponse = new ResponseHandlerResponse();
        handlerResponse.setReturnCode(0);
        return handlerResponse;
    }

    public ResponseHandlerResponse handleEventResponse(ArgumentsList arguments){
        log.info(String.format("handleEventResponse>>> %s", arguments.getApiRequest().getRequestId()));
        ResponseHandlerResponse handlerResponse = new ResponseHandlerResponse();
        handlerResponse.setReturnCode(0);
        return handlerResponse;
    }

}

