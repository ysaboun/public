package com.bnppf.filter.config;

import com.bnppf.filter.model.AuthorizedUri;
import com.bnppf.filter.model.FilterSecurity;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "poc.filter", ignoreUnknownFields = true)
@PropertySource(value = "classpath:/config/filter.yml")
public class FilterConfiguration {
    private FilterSecurity filterSecurity;
    private String trustedPath;
    private List<String> uriToFilter;
    private List<String> requiredHeaders;
    private List<AuthorizedUri> authorizedUri;

    public FilterSecurity getFilterSecurity() {
        return filterSecurity;
    }

    public void setFilterSecurity(FilterSecurity filterSecurity) {
        this.filterSecurity = filterSecurity;
    }

    public String getTrustedPath() {
        return trustedPath;
    }

    public void setTrustedPath(String trustedPath) {
        this.trustedPath = trustedPath;
    }

    public List<String> getUriToFilter() {
        return uriToFilter;
    }

    public void setUriToFilter(List<String> uriToFilter) {
        this.uriToFilter = uriToFilter;
    }

    public List<String> getRequiredHeaders() {
        return requiredHeaders;
    }

    public void setRequiredHeaders(List<String> requiredHeaders) {
        this.requiredHeaders = requiredHeaders;
    }

    public List<AuthorizedUri> getAuthorizedUri() {
        return authorizedUri;
    }

    public void setAuthorizedUri(List<AuthorizedUri> authorizedUri) {
        this.authorizedUri = authorizedUri;
    }
}
