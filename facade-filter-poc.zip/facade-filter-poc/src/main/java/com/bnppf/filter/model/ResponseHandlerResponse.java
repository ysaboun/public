package com.bnppf.filter.model;

public class ResponseHandlerResponse {
    /**
     * handler execution return code
     */
    private int returnCode;

    /**
     * http status to returned
     */
    private int status;

    /**
     * exception to generate if returnCode is not equal to 0
     */
    private BusinessFilterException exception;

    public int getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }

    public BusinessFilterException getException() {
        return exception;
    }

    public void setException(BusinessFilterException exception) {
        this.exception = exception;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
