package com.bnppf.filter.model;


import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ArgumentsList {
    /**
     * original servlet request
     */
    private ServletRequest request;

    /**
     * wrapped servlet response
     */
    private ServletResponse response;

    /**
     * validation response
     */
    private ValidateResponse validateResponse;

    /**
     * body
     */
    private String body;

    public ArgumentsList(ServletRequest request, ServletResponse response, ValidateResponse validateResponse) {
        super();
        this.validateResponse = validateResponse;
        this.request = request;
        this.response = response;
    }

    public ArgumentsList(ServletRequest request, ServletResponse response, ValidateResponse validateResponse, String payload) {
        super();
        this.validateResponse = validateResponse;
        this.request = request;
        this.response = response;
        this.body = payload;
    }

    public ServletRequest getRequest() {
        return request;
    }

    public void setRequest(ServletRequest request) {
        this.request = request;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public ValidateResponse getValidateResponse() {
        return validateResponse;
    }

    public void setValidateResponse(ValidateResponse validateResponse) {
        this.validateResponse = validateResponse;
    }

    public ServletResponse getResponse() {
        return response;
    }

    public void setResponse(ServletResponse response) {
        this.response = response;
    }

    public ApiRequest getApiRequest(){
        return validateResponse.getApiRequest();
    }

    public HttpServletRequest getHttpRequest(){
        return (HttpServletRequest) request;
    }

    public HttpServletResponse getHttpResponse(){
        return (HttpServletResponse) response;
    }
}
