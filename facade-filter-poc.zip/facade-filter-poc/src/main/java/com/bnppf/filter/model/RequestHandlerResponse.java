package com.bnppf.filter.model;

public class RequestHandlerResponse {
    /**
     * handler execution return code
     */
    private int returnCode;

    /**
     * exception to generate if returnCode is not equal to 0.
     */
    private BusinessFilterException exception;

    public int getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }

    public BusinessFilterException getException() {
        return exception;
    }

    public void setException(BusinessFilterException exception) {
        this.exception = exception;
    }
}
