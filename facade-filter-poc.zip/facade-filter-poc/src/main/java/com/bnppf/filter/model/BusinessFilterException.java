package com.bnppf.filter.model;

public class BusinessFilterException extends Exception{
 public BusinessFilterException(final String message){
     super(message);
 }

 public BusinessFilterException(final String message, final Throwable cause){
     super(message, cause);
 }
}
