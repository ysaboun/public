package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.*;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingResponseWrapper;
import org.springframework.web.util.WebUtils;

import java.io.IOException;

@Component
public class ResponseFilter {

    private static final Logger log = LoggerFactory.getLogger(ResponseFilter.class);

    @Autowired
    FilterConfiguration configuration;

    @Autowired
    ResponseHandler responseHandler;

    public void run(HttpServletRequest request, HttpServletResponse response, ValidateResponse apiValidation) throws FilterException {
        boolean clientError = response.getStatus() >= 400 && response.getStatus() < 500;
        boolean serverError = response.getStatus() >= 500;

        boolean trusted = request.getRequestURI().startsWith(configuration.getTrustedPath());

        if (clientError || serverError){
            log.info(String.format("response has error status code %d", response.getStatus()));
        }

        ContentCachingResponseWrapper wrapper =
                WebUtils.getNativeResponse(response, ContentCachingResponseWrapper.class);

        String payload = null;

        try{
            if(wrapper != null){
                byte[] buf = wrapper.getContentAsByteArray();
                if(buf.length > 0){
                    payload = new String(buf,0, buf.length, wrapper.getCharacterEncoding());
                }
                // trace
                log.info(String.format("Response body is: %s", payload));

                if(!trusted && !clientError && !serverError){
                    handleResponse(request, wrapper, apiValidation, payload);
                }
                setheaders(request, wrapper, payload, apiValidation.getApiRequest(), serverError||clientError);
                wrapper.copyBodyToResponse();
            }
        } catch (IOException e){
            throw new FilterException(e.getMessage(), Constant.ERRORS.STATUS_400);
        }


    }

    private void setheaders(HttpServletRequest request, ContentCachingResponseWrapper wrapper, String payload, ApiRequest apiRequest, boolean error) {

    boolean trusted = request.getRequestURI().startsWith(configuration.getTrustedPath());
    if(payload !=null){
        //digest
    }
        //setcache(wrapper)
        //setDate(wrapper)
        //sign (if sign response)
        //trace

        if(!wrapper.containsHeader(configuration.getFilterSecurity().getHeaderRequestId().toLowerCase())){
            wrapper.addHeader(
                    configuration.getFilterSecurity().getHeaderRequestId().toLowerCase(), apiRequest.getRequestId()
            );
        }
        for(String s: wrapper.getHeaderNames()) {
            log.info(String.format("header %s = %s", s, wrapper.getHeader(s)));
        }
        //audit log
        //if(!trusted && configuration.isAuditLog())
    }

    /**
     * do staff for this request. We use Java>=8 method referencing mechanism
     */
    private ResponseHandlerResponse handleResponse(ServletRequest request, ServletResponse response, ValidateResponse validateResponse,
                                                   String payload){
        APisRequest.REQUEST_TYPES req = APisRequest.REQUEST_TYPES.valueOf(validateResponse.getUriDescription().getType());
        return responseHandler.getHandlers().get(req.type())
                .apply(new ArgumentsList(request, response, validateResponse, payload));
    }
}
