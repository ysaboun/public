package com.bnppf.filter.model;

public class ApiNone {
    public ApiNone(){}
}
