package com.bnppf.filter;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.handler.*;
import com.bnppf.filter.model.APisRequest;
import com.bnppf.filter.model.Constant;
import com.bnppf.filter.model.FilterException;
import com.bnppf.filter.model.ValidateResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;


@Component
public  class PocFilter extends OncePerRequestFilter {
    private static final Logger log = LoggerFactory.getLogger(PocFilter.class);

    @Autowired
    FilterLogHandler apiLogHandler;

    @Autowired
    ApiRequestFilter apiRequestFilter;

    @Autowired
    RequestHandler requestHandler;

    @Autowired
    ResponseHandler responseHandler;

    @Autowired
    FilterConfiguration configuration;

    @Autowired
    ResponseToClient responseToClient;

    @Autowired
    ResponseFilter responseFilter;

    @Override
    public  void  doFilterInternal  (HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)  throws IOException, ServletException {
        ValidateResponse apiValidation = null;
        log.info(String.format("Enter in doFilter for servlet path %s", request.getServletPath()));

        try{
            /**
             * log handler
             */
            apiLogHandler.prepareLogging(request);

            log.info(String.format("Enter in doFilter for servlet path %s", request.getServletPath()));

            /**
             * Validate the request and eventually answer immediately to defrred execution.
             */
            apiValidation = apiRequestFilter.run(request, response);

            /**
             * If isDoNotContinue is set, then requestFlter has already sent a response or
             * an error. Otherwise, we continue in sequence (through other filters if exist).
             */
            if(!apiValidation.isDoContinue()){
                log.info("isDoContinue: "+apiValidation.isDoContinue());
                return;
            }

            log.info("We continue in filter control is given to servlet....");
            HttpServletResponse responseWrapper = new ContentCachingResponseWrapper(response);
            filterChain.doFilter(request, responseWrapper);

            try {
                responseFilter.run(request, responseWrapper, apiValidation);
            } catch (FilterException e){
                log.info(String.format("Response validation error : %s", e.getMessage()));
                responseToClient.sendError(request, response, e);
            }


        }catch (Exception ex){
            String requestId = "Unknown";
            if(apiValidation.getApiRequest() !=null){
                requestId =  apiValidation.getApiRequest().getRequestId();
            }
            responseToClient.sendError(request, response,
                    new FilterException("server error", Constant.ERRORS.STATUS_500));//requestId
        }finally {
            MDC.clear();
        }
    }

    @Override
    public void destroy() {
        // Cleanup logic if needed
        log.info("Destroying CustomOncePerRequestFilter");
    }

    /**
     * show handled URI configuration and detect filter.yml errors
     */
    @Override
    public void initFilterBean(){
        /**
         * fill request handlers map in relation with filter.yml properties file
         */
        requestHandler.getHandlers().put(APisRequest.REQUEST_TYPES.ACCOUNTS_REQUEST.type(), requestHandler::handleAccountsRequest);
        requestHandler.getHandlers().put(APisRequest.REQUEST_TYPES.EVENT_REQUEST.type(), requestHandler::handleEventRequest);

        /**
         * fill response handlers map in relation with filter.yml propreties file
         */
        responseHandler.getHandlers().put(APisRequest.REQUEST_TYPES.ACCOUNTS_REQUEST.type(), responseHandler::handleAccountsResponse);
        responseHandler.getHandlers().put(APisRequest.REQUEST_TYPES.EVENT_REQUEST.type(), responseHandler::handleEventResponse);

        log.info("URI parsed by this filter: ");
        int i=0;
        try{
            for (;i<configuration.getAuthorizedUri().size(); i++){
                String.format("%d. %s (%s)", i, configuration.getAuthorizedUri().get(i).toString(),
                        APisRequest.REQUEST_TYPES.valueOf(configuration.getAuthorizedUri().get(i).getType()).type());
            }
        }catch (IllegalArgumentException ex){
            String message = String.format(
                    "Filter initialization: error in filter.yml file. The previous AuthorizedUrl item references a type not specified in apim constant class: %s",
                    configuration.getAuthorizedUri().get(i).getType());
            //error log
            throw new FatalBeanException(message);
        }
        //set headers to lower case
        configuration.getRequiredHeaders().replaceAll(String::toLowerCase);
    }

    /**
     * determine if filter must be done
     * @param request {@link HttpServletRequest} object
     * @return true if should be filter
     */
    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request){
        AntPathMatcher antPathMatcher = new AntPathMatcher();
        return configuration.getUriToFilter().stream().noneMatch( uri -> antPathMatcher.match(uri, request.getServletPath()));
    }
}