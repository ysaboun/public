package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.*;
import com.bnppf.model.BusinessRequest;
import com.bnppf.model.RequestResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * class to handle request
 */
@Component
public class RequestHandler {

    private static final Logger log = LoggerFactory.getLogger(RequestHandler.class);

    private final Map<String, Function<ArgumentsList, RequestHandlerResponse>> handlers = new HashMap<>();

    public Map<String, Function<ArgumentsList, RequestHandlerResponse>> getHandlers() {
        return handlers;
    }

    /**
     * class useed to send response or error
     */
    @Autowired
    ResponseToClient responseToClient;

    @Autowired
    FilterConfiguration configuration;

    /**
     * Handle accounts request. Here we suppose something to do at this level.
     * If it's not the case, then set doContinue to true in RequestValidator but this
     * suppose a flag to implement in the filter properties for this kind of request.
     *
     * @param arguments {@link ArgumentsList} object
     * @return RequestHandlerResponse object.
     */
    public RequestHandlerResponse handleAccountsRequest(ArgumentsList arguments){
        log.info(String.format("handleAccountsRequest>>>>>", arguments.getApiRequest().getRequestId()));
        return standardRequestHandling(arguments);
    }

    /**
     * Handle event post request.
     * @param arguments
     * @return
     */
    public RequestHandlerResponse handleEventRequest(ArgumentsList arguments){
        log.info(String.format("handleEventRequest>>>>>", arguments.getApiRequest().getRequestId()));

        //ensure the body request is conform to expected object
        ApiRequest aPisRequest = arguments.getApiRequest();
        RequestResource requestResource = (RequestResource) aPisRequest.getRequest();

        RequestHandlerResponse requestHandlerResponse = new RequestHandlerResponse();
        aPisRequest.setRequestType(APisRequest.REQUEST_TYPES.EVENT_REQUEST.type());
        //aPisRequest.setTimestamp(new Date().getTime());
        //requestResource.setData();
        BusinessRequest<RequestResource> businessRequest = new BusinessRequest<>();
        businessRequest.setRequest(requestResource);
        businessRequest.setRequestId(arguments.getApiRequest().getRequestId());
        businessRequest.setHeaders(arguments.getApiRequest().getHeaders());
        businessRequest.setRequestId(arguments.getApiRequest().getRequestId());
        businessRequest.setRequestPath(arguments.getApiRequest().getRequestUri());

        arguments.getRequest().setAttribute("business-request", businessRequest);
        arguments.getValidateResponse().setDoContinue(true);
        requestHandlerResponse.setReturnCode(0);

        return requestHandlerResponse;
    }

    private RequestHandlerResponse standardRequestHandling(ArgumentsList arguments){
        BusinessRequest<ApiNone> request = new BusinessRequest<>();
        request.setRequest(new ApiNone());
        fillRequest(request, arguments);
        arguments.getRequest().setAttribute("business-request", request);
        arguments.getValidateResponse().setDoContinue(true);

        RequestHandlerResponse response = new RequestHandlerResponse();
        response.setReturnCode(0);
        return response;
    }

    private <T> BusinessRequest<T> fillRequest(BusinessRequest<T> businessRequest, ArgumentsList arguments){
        businessRequest.setHeaders(arguments.getApiRequest().getHeaders());
        businessRequest.setRequestId(arguments.getApiRequest().getRequestId());
        businessRequest.setRequestPath(arguments.getApiRequest().getRequestUri());
        businessRequest.setAccessToken(arguments.getApiRequest().getToken());

        return businessRequest;
    }
}
