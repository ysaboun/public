package com.bnppf.filter.model;

import com.bnppf.filter.config.BypassConfiguration;
import com.bnppf.model.RequestResource;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.io.CharStreams;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.*;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import static org.springframework.util.StringUtils.isEmpty;


public class BypassApiFilter implements Filter {
    private static final Logger log = LoggerFactory.getLogger(BypassApiFilter.class);

    @Autowired
    private BypassConfiguration bypassConfiguration;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        if(bypassConfiguration.isEnable()){

            final Map<Object, String[]> parameters = Collections.list(request.getParameterNames())
                    .stream().collect(Collectors.toMap(paramName -> paramName, request::getParameterValues));

            ResettableStreamHttpServletRequest wrappedRequest = new ResettableStreamHttpServletRequest((HttpServletRequest) request);
            String body = com.google.common.io.CharStreams.toString(wrappedRequest.getReader());

            RequestResource requestResource = null;
            if (!isEmpty(body)){
                ObjectMapper objectMapper = initObjectMapper();
                requestResource = objectMapper.readValue(body, RequestResource.class);
            }

            if(requestResource != null){
                ApiRequest<RequestResource> fakeRequest = new ApiRequest<>();
                fakeRequest.setRequest(requestResource);
                request.setAttribute("business-request", fakeRequest);
            }else {
                ApiRequest<ApiNone> fakeRequest = new ApiRequest<>();
                request.setAttribute("business-request", fakeRequest);
            }
        }

        chain.doFilter(request, response);
    }

    private ObjectMapper initObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.registerModule(new Jdk8Module());
        return objectMapper;
    }

    public static class ResettableStreamHttpServletRequest extends HttpServletRequestWrapper {

        private byte[] rawData;
        private final HttpServletRequest request;
        private final ResettableServletInputStream servletStream;

        public ResettableStreamHttpServletRequest(HttpServletRequest request) {
            super(request);
            this.request = request;
            this.servletStream = new ResettableServletInputStream();
        }

        @Override
        public ServletInputStream getInputStream() throws IOException {
            readRawData();
            return servletStream;
        }

        private void readRawData() throws IOException {
            if (rawData == null) {
                rawData = CharStreams.toString(request.getReader()).getBytes();
            }
            servletStream.stream = new ByteArrayInputStream(rawData);
        }

        @Override
        public BufferedReader getReader() throws IOException {
            readRawData();
            return new BufferedReader(new InputStreamReader(servletStream));
        }

        public void resetInputStream(byte[] rawData) {
            this.rawData = rawData;
            servletStream.stream = new ByteArrayInputStream(rawData);
        }

        private static class ResettableServletInputStream extends ServletInputStream {

            private InputStream stream;

            @Override
            public int read() throws IOException {
                return stream.read();
            }

            @Override
            public boolean isFinished() {
                return false;
            }

            @Override
            public boolean isReady() {
                return true;
            }

            @Override
            public void setReadListener(ReadListener listener) {
            }
        }
    }
}
