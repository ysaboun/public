package com.bnppf.filter.model;

public class Constant {
    public static enum ERRORS {
        STATUS_400(400, "Bad request"),
        STATUS_401(401, "Unauthorized, authentication failure."),
        STATUS_403(403, "Forbiden, authentication successful but acces to resource is not allowed."),
        STATUS_500(500, "Internal server error"),
        STATUS_502(502, "Bad Gateway"),
        STATUS_405(405, "xxx.");

        private final int status;

        private final String explanation;

        private ERRORS(int status, String explanation){
            this.status = status;
            this.explanation = explanation;
        }

        public int status() {
            return status;
        }

        public String explanation() {
            return explanation;
        }
    }
}
