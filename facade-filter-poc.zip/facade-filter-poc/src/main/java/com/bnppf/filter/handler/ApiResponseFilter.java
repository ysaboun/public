package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.ValidateResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * handle a handled response for request wich continued through the filter
 * . If it was a trusted request, do not send audit 'request-out'
 * because it's already done by the request handler
 */
@Component
public class ApiResponseFilter {

    @Autowired
    FilterConfiguration configuration;

    @Autowired
    ResponseHandler responseHandler;

    /**
     * custom actions on reponse
     */
    public void run(HttpServletRequest request, HttpServletResponse response, ValidateResponse validateResponse){}
}
