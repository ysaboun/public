package com.bnppf.filter.model;

public class ValidateResponse {

    private ApiRequest apiRequest;
    private boolean doContinue;
    private AuthorizedUri uriDescription;

    public boolean isDoContinue() {
        return doContinue;
    }

    public void setDoContinue(boolean doContinue) {
        this.doContinue = doContinue;
    }

    public ApiRequest getApiRequest() {
        return apiRequest;
    }

    public void setApiRequest(ApiRequest apiRequest) {
        this.apiRequest = apiRequest;
    }

    public AuthorizedUri getUriDescription() {
        return uriDescription;
    }

    public void setUriDescription(AuthorizedUri uriDescription) {
        this.uriDescription = uriDescription;
    }
}
