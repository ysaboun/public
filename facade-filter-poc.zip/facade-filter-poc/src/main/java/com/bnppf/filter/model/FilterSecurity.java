package com.bnppf.filter.model;


public class FilterSecurity {
    private String authorizationHeader;
    private String headerRequestId;
    private String headerOriginHost;
    private String headerOriginPath;
    private String jwtHeader;
    private FilterSignature filterSignature;

    public String getAuthorizationHeader() {
        return authorizationHeader;
    }

    public void setAuthorizationHeader(String authorizationHeader) {
        this.authorizationHeader = authorizationHeader;
    }

    public String getHeaderRequestId() {
        return headerRequestId;
    }

    public void setHeaderRequestId(String headerRequestId) {
        this.headerRequestId = headerRequestId;
    }

    public String getHeaderOriginHost() {
        return headerOriginHost;
    }

    public void setHeaderOriginHost(String headerOriginHost) {
        this.headerOriginHost = headerOriginHost;
    }

    public String getHeaderOriginPath() {
        return headerOriginPath;
    }

    public void setHeaderOriginPath(String headerOriginPath) {
        this.headerOriginPath = headerOriginPath;
    }

    public String getJwtHeader() {
        return jwtHeader;
    }

    public void setJwtHeader(String jwtHeader) {
        this.jwtHeader = jwtHeader;
    }

    public FilterSignature getFilterSignature() {
        return filterSignature;
    }

    public void setFilterSignature(FilterSignature filterSignature) {
        this.filterSignature = filterSignature;
    }
}
