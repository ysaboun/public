package com.bnppf.filter.model;

public class FilterSignature {
    private String publicKeyUrl;
    private String signatureHeader;

    // getter & setter
}
