package com.bnppf.filter.model;

public class AuthorizedUri {
    private String uriRegexp;
    private String method;
    private String type;
    private String apiContext;

    public String getUriRegexp() {
        return uriRegexp;
    }

    public void setUriRegexp(String uriRegexp) {
        this.uriRegexp = uriRegexp;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getApiContext() {
        return apiContext;
    }

    public void setApiContext(String apiContext) {
        this.apiContext = apiContext;
    }
}
