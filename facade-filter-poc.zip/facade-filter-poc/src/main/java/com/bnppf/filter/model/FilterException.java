package com.bnppf.filter.model;

public class FilterException extends Exception {
    private Constant.ERRORS error;

    private String requestId;

    public FilterException(Constant.ERRORS error) {
        super(error.explanation());
        this.error = error;
    }

    public FilterException(String message, Constant.ERRORS error) {
        super(message);
        this.error = error;
    }

    public FilterException(String message, Throwable cause, Constant.ERRORS error) {
        super(message, cause);
        this.error = error;
    }

    public Constant.ERRORS getError() {
        return error;
    }

    public String getExplanation(){
        return this.error.explanation();
    }

    public int getStatus(){
        return this.error.status();
    }

    public String getRequestId() {
        return requestId;
    }
}
