package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.*;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class ApiRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(ApiRequestFilter.class);

    @Autowired
    FilterConfiguration configuration;

    @Autowired
    RequestValidator requestValidator;

    @Autowired
    RequestHandler requestHandler;

    public ValidateResponse run(ServletRequest request, ServletResponse response) throws IOException, BusinessFilterException, FilterException, FilterException {

        /**
         * validate the request. If the response has doContinue to true,
         * then bypass handlerrequest and pass directly to filter to join api
         */
        log.info("validate the request : requestValidator.validate ");
        ValidateResponse validateResponse = requestValidator.validate(request);

        /**
         * if true is set at the step, it's a trusted request coming from
         * backend x internal
         */
        if(validateResponse.isDoContinue()){
             log.info("if isDoContinue : Continue in filter bypassing handleRequest");
             return validateResponse;
        }

        log.info("In requestFiltrer, apiRequest is "+ validateResponse.getApiRequest());
        RequestHandlerResponse handlerResponse = handleRequest(request, response, validateResponse);

        /**
         * test handler execution result
         */
        if(handlerResponse.getReturnCode() != 0){
            throw  handlerResponse.getException();
        }else{
            // at this stade we have an request to
            // execute passing through the filter
            // validate response isDFoContinue updated by handlerRequest
            //in all case do audit work key= request-in
            //if(configuration.isAuditLog())
        }
        return validateResponse;
    }

    private RequestHandlerResponse handleRequest (ServletRequest request, ServletResponse response, ValidateResponse validateResponse){
        APisRequest.REQUEST_TYPES req  = APisRequest.REQUEST_TYPES.valueOf(validateResponse.getUriDescription().getType());
        return requestHandler.getHandlers().get(req.type())
                .apply(new ArgumentsList(request, response, validateResponse));
    }
}
