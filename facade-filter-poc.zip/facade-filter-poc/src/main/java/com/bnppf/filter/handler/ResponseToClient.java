package com.bnppf.filter.handler;

import com.bnppf.filter.config.FilterConfiguration;
import com.bnppf.filter.model.Constant;
import com.bnppf.filter.model.FilterException;
import com.bnppf.filter.model.ValidateResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Map;

@Component
public class ResponseToClient {

    private static final Logger log = LoggerFactory.getLogger(ResponseToClient.class);

    @Autowired
    FilterConfiguration configuration;

    public void send(ServletRequest request, ServletResponse response, ValidateResponse validateResponse,
                     Object body, Map<String,String> extraHeaders, int httpStatus) throws FilterException {

       HttpServletRequest httpServletRequest = (HttpServletRequest) request;
       HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        /**
         * 1. set headers
         */
        setCommonHeader(httpServletResponse, validateResponse.getApiRequest().getRequestId());
        if(extraHeaders !=null){
            for(String header: extraHeaders.keySet()){
                httpServletResponse.setHeader(header, extraHeaders.get(header));
            }
        }

        /**
         * 2. build body digest if required (body present or not)
         *
         */
        String bodyString = null;
        try {
            if(body !=null){
                ObjectMapper mapper = new ObjectMapper();
                bodyString = mapper.writeValueAsString(body);
                byte[] digestDigit = null;//DigestUtils.sha256(bodyString);
                String digest = String.format("SHA-256=%s", Base64.getEncoder().encodeToString(digestDigit));
                //setDigest(httpServletRequest, digest);
            }
        }catch (JsonProcessingException ex){
            //log error
            throw new FilterException(String.format("Bad body format: %S", ex.getMessage()), Constant.ERRORS.STATUS_400);
        }

        /**
         * sign response
         */
        //boolean ret = sign()
        for(String header: httpServletResponse.getHeaderNames()){
            log.info(String.format("Header %s sent with value %s", header, httpServletResponse.getHeader(header)));
        }

        /**
         * 4 send
         */

        try{
            ByteArrayOutputStream out = getOutputStream(bodyString);
            httpServletResponse.setContentLength(out.size());
            httpServletResponse.setStatus(httpStatus);
            out.writeTo(response.getOutputStream());
        }catch (IOException ex){
            //log error
            //send error 500
            httpServletResponse.setStatus(Constant.ERRORS.STATUS_500.status());
        }

    }

    public void sendError(HttpServletRequest request, HttpServletResponse response, FilterException e) {
        HttpServletRequest httpRequest= (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse)response;

        httpResponse.setStatus(e.getError().status());
        setCommonHeader(httpResponse, e.getRequestId());
        JSONObject body = new JSONObject();

        if (log.isDebugEnabled()){
            for (String h : httpResponse.getHeaderNames()){
                log.info(String.format("Response header: %s:%s", h, httpResponse.getHeader(h)));
            }
        }

        try {
            body.put("error", e.getError().explanation());
            body.put("message", e.getMessage());
            body.put("timestamp", ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSxxxx")));
            body.put("path", httpRequest.getRequestURI());

            String stringBody = body.toString().replace("\\", "");
            ByteArrayOutputStream out = getOutputStream(stringBody);
            httpResponse.setContentLength(out.size());
            out.writeTo(response.getOutputStream());
        } catch (IOException ex){
            log.info(String.format("Cannot send error message. Error is : %s", ex.getMessage()));
            httpResponse.setStatus(Constant.ERRORS.STATUS_500.status());
        }
    }

    private void setCommonHeader(HttpServletResponse httpResponse, String requestId) {
      HttpServletResponse httpServletResponse = (HttpServletResponse) httpResponse;
      //httpServletResponse.setContentType(httpResponse, "json");
      //setCache()
      //setDate
      httpServletResponse.setHeader(configuration.getFilterSecurity().getHeaderRequestId(), requestId);
      httpServletResponse.setHeader("Content-Type", "application/hal+json; charset=utf-8");
    }

    private ByteArrayOutputStream getOutputStream(String stringBody) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(stringBody.length());
        PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8));
        printWriter.write(stringBody);
        printWriter.flush();

        return out;
    }
}
