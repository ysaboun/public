package com.bnppf.model;

import javax.validation.constraints.AssertTrue;

@CoherenceConstraint()
public class RequestResource {

    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @AssertTrue()
    public boolean containFacade(){
        if(getData() != null){
            return getData().contains("facade");
        }
        return false;
    }
}
