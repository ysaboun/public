package com.bnppf.model;

import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

@Component
public class ValidatorFacade {

    private Validator getValidator(){
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        return factory.getValidator();
    }

    public void c(BusinessRequest<RequestResource> businessRequest){
        Set<ConstraintViolation<RequestResource>> violations = getValidator().validate(businessRequest.getRequest());

        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (ConstraintViolation<RequestResource> violation : violations) {
                sb.append("violation message = "+violation.getMessage()).append("\n");
            }
            throw new IllegalArgumentException("request validation failed: \n" + sb);
        }

        System.out.println("control facade successfully");
    }
}
