package com.bnppf.model;

import java.util.Map;

/**
 * DTO to be used to dialog with business services.
 * @param <T> is the business request class type
 * @author y
 */
public class BusinessRequest<T> extends AbstractApiRequest {
    /**
     * internal request id
     */
    private String requestId;


    private String requestPath;
    private String accessToken;

    /**
     * headers
     */
    private Map<String, String> headers;

    /**
     * request object depending on type
     */
    private T request;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public T getRequest() {
        return request;
    }

    public void setRequest(T request) {
        this.request = request;
    }

    public String getRequestPath() {
        return requestPath;
    }

    public void setRequestPath(String requestPath) {
        this.requestPath = requestPath;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
