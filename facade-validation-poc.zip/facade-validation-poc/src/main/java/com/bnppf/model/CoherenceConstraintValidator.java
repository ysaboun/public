package com.bnppf.model;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CoherenceConstraintValidator implements ConstraintValidator<CoherenceConstraint, RequestResource> {
    @Override
    public boolean isValid(RequestResource requestResource, ConstraintValidatorContext context) {
        boolean isValid = true;
        if(requestResource != null){
            if(!requestResource.containFacade()){
                isValid = false;
                context.buildConstraintViolationWithTemplate("requestResource data must contain facade")
                        .addPropertyNode("requestResource data")
                        .addConstraintViolation();
                /*
                    String defaultErrorMessage = context.getDefaultConstraintMessageTemplate();
                    String formattedErrorMessage = String.format(defaultErrorMessage, new Date());

                    context.disableDefaultConstraintViolation();
                    context.buildConstraintViolationWithTemplate(formattedErrorMessage).addConstraintViolation();
                */
            }
            return isValid;
        }
        return true;
    }
}
