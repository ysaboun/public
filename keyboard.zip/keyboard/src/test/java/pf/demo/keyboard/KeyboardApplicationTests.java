package pf.demo.keyboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
