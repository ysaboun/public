$(function(){
        $.ajax({
            type: "GET",
            contentType: "application/json",
            url: "/keyboardAndEncryptedSeed",
            dataType: 'json',
            timeout: 600000,
            success: function (data) {
                 const obj = JSON.parse(JSON.stringify(data));
                 var tempArray = keyboard.getKeyboard(obj);
                 for(i=0; i<tempArray.length; i++){
                      $('#keyboard_div').append('<span class="keyboard_position" id="posic_'+i+'"></span>');
                      if(i == 4) $('#keyboard_div').append('<br/>');
                      $('#posic_'+i).val(i);
                      $('#posic_'+i).text(tempArray[i]);
                      $('#posic_'+i).click(function(e){
                            if($('#keyboard_input').val().length < 20){
                                $('#keyboard_input').val($('#keyboard_input').val() + e.target.value);
                                stateValiderButton($('#keyboard_input'));
                            }
                      });
                 }
                 stateValiderButton($('#keyboard_input'));
            },
            error: function (e) {
                console.log("ERROR : ", e);
            }
        });

        $("#reset").click(function(){
            $('#keyboard_input').val("");
            stateValiderButton($('#keyboard_input'));
        });
 });

function stateValiderButton(element){
  if(element.val().length < 6){
      $("#keyboard_button").attr("disabled", true);
  }else{
      $("#keyboard_button").attr("disabled", false);
  }
}

let keyboard = {
   seed:null,
   keyboard: null,
   setSeed: function (value){this.seed = value;},
   setKeyboard: function (value){this.keyboard = value;},
   getKeyboard: function(obj){
       this.setSeed(obj.encryptedSeed);
       this.setKeyboard(obj.keyboard);
       return this.keyboard.split("");
   },
   buildReponse: function(value){
        const myObject = {
          encryptedSeed: this.seed,
          keypad: value
        };
        return myObject;
    }
};

function buildResponse(){
    let code= $('#keyboard_input').val();
    let response = keyboard.buildReponse(code);
    $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "/keypadAndEncryptedSeed",
            data: JSON.stringify(response),
            dataType: 'json',
            cache: false,
            timeout: 600000,
            success: function (data) {
                console.log("data : ", data);
                if(data == true){
                  $(location).prop('href', 'succes');
                }else{
                  $(location).prop('href', 'login?error=error');
                }
            },
            error: function (e) {
                $(location).prop('href', 'login?error=error');
                console.log("ERROR : ", e);
            }
    });
}



