package pf.demo.keyboard;

public class KeypadAndEncryptedSeed {
    private String keypad;
    private String encryptedSeed;

    public String getKeypad() {
        return keypad;
    }

    public void setKeypad(String keypad) {
        this.keypad = keypad;
    }

    public String getEncryptedSeed() {
        return encryptedSeed;
    }

    public void setEncryptedSeed(String encryptedSeed) {
        this.encryptedSeed = encryptedSeed;
    }
}
