package pf.demo.keyboard;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class KeyBoardController {
    @GetMapping("/login")
    public String keyboard(@RequestParam(required = false) String error, Model model){
        if(error != null) model.addAttribute("error_message", "authentification KO");
        return "index";
    }

    @GetMapping("/succes")
    public String succes(){
        return "succes";
    }
}