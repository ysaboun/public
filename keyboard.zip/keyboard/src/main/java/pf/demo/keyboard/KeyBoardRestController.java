package pf.demo.keyboard;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static pf.demo.keyboard.Authentication.buildKeyboardAndSeed;
import static pf.demo.keyboard.Authentication.decodeKeypadAndEncryptedSeed;


@RestController
public class KeyBoardRestController {
    @GetMapping("/keyboardAndEncryptedSeed")
    public String keyboardAndEncryptedSeed(){
        return buildKeyboardAndSeed();
    }

    @PostMapping("/keypadAndEncryptedSeed")
    public boolean keypadAndEncryptedSeed(@RequestBody KeypadAndEncryptedSeed keypadAndEncryptedSeed){
        return decodeKeypadAndEncryptedSeed(keypadAndEncryptedSeed);
    }
}