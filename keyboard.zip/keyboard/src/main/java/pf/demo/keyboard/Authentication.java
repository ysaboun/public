package pf.demo.keyboard;


import com.google.gson.Gson;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import static pf.demo.keyboard.Crypt.decrypt;

public class Authentication {

    static String buildKeyboardAndSeed() {
        //set seed
        String seed = uuid();
        System.out.println("1. seed=" + seed);

       long ttl = Instant.now().plus(Duration.ofSeconds(120)).toEpochMilli();
        System.out.println("2. ttl=" + ttl);

        String concatSeedAndTTL = seed.concat("_").concat(String.valueOf(ttl));
        System.out.println("3. concatSeedAndTTL=" + concatSeedAndTTL);

        String keyboard = Positions.generateKeyBoard(seed);
        System.out.println("4. keyboard=" + keyboard);
        String encryptedConcatSeedAndTTL= Crypt.encrypt(concatSeedAndTTL);

        KeyboardAndSeed keyboardAndSeed = new KeyboardAndSeed();
        keyboardAndSeed.setKeyboard(keyboard);
        keyboardAndSeed.setEncryptedSeed(encryptedConcatSeedAndTTL);

        String json = new Gson().toJson(keyboardAndSeed);
        System.out.println("5. keyboardAndSeed=" + json);

        return json;
    }

    static boolean decodeKeypadAndEncryptedSeed(KeypadAndEncryptedSeed keypadAndEncryptedSeed) {

        //split
        System.out.println("6. keypadAndEncryptedSeed=" + new Gson().toJson(keypadAndEncryptedSeed));
        String keypad = keypadAndEncryptedSeed.getKeypad();
        String encryptedConcatSeedAndTTL = keypadAndEncryptedSeed.getEncryptedSeed();

       //decrypt
        String decryptedConcatSeedAndTTL = decrypt(encryptedConcatSeedAndTTL);
        System.out.println("7. decryptedConcatSeedAndTTL=" + decryptedConcatSeedAndTTL);

        long ttl = Long.parseLong(decryptedConcatSeedAndTTL.split("_")[1]);
        long now = Instant.now().toEpochMilli();

        if(now < ttl){
            System.out.println("TTL  NON expiration seed");
            String decryptedSeed = decryptedConcatSeedAndTTL.split("_")[0];
            System.out.println("8. decryptedSeed="+decryptedSeed);

            //generate positions by seed
            String keyboardPosition = Positions.generateKeyBoard(decryptedSeed);
            System.out.println("9. keyboardPosition=" + keyboardPosition);

            String password = retreivePassword(keyboardPosition, keypad);
            System.out.println("10. password=" + password);

            return password.equals("160624");
        }else {
            System.out.println("TTL expiration seed");
            return false;
        }
    }

    private static String uuid() {
        //UUID uuid1 = UUID.randomUUID();
        //return uuid.toString();

        SecureRandom secureRandom = new SecureRandom();
        byte[] randomBytes = new byte[16];
        secureRandom.nextBytes(randomBytes);

        // Set the version to 4 (random UUID)
        randomBytes[6] &= 0x0f; //clear version
        randomBytes[6] |= 0x40; // set to version 4

        // Set the variant to 2 (IETF variant)
        randomBytes[8] &= 0x3f;// clear variant
        randomBytes[8] |= 0x80; // set to IETF variant

        UUID uuid = UUID.nameUUIDFromBytes(randomBytes);
        return  uuid.toString();
    }

    private static String retreivePassword(String keyboardPosition, String userKeypadSplited) {
        char[] charsToucheUser = userKeypadSplited.toCharArray();
        StringBuilder sb = new StringBuilder();
        for (char c : charsToucheUser) {
            int i = Character.getNumericValue(c);
            sb.append(keyboardPosition.charAt(i));
        }

        return sb.toString();
    }
}