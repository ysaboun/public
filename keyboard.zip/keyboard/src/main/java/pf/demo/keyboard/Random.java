package pf.demo.keyboard;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * random number generator
 *
 */
public class Random {
    private byte[] K;
    private byte[] V;

    public Random(byte[] seed) throws NoSuchAlgorithmException, InvalidKeyException {
        this.init(seed);
    }

    public void init(byte[] seed) throws NoSuchAlgorithmException, InvalidKeyException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] KInit = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        byte[] VInit = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

        //KTmp
        buffer.reset();
        buffer.write(VInit, 0, 32);
        buffer.write(0x00);
        buffer.write(seed, 0, seed.length);
        byte[] KTmp = Random.hmacSha256(KInit, buffer.toByteArray());

        //VTmp
        byte[] VTmp = Random.hmacSha256(KTmp, VInit);

        //K
        buffer.reset();
        buffer.write(KInit, 0, 32);
        buffer.write(0x00);
        buffer.write(seed, 0, seed.length);
        this.K = Random.hmacSha256(KTmp, buffer.toByteArray());

        //V
        this.V = Random.hmacSha256(this.K, VTmp);

    }

    //draw a new random number
    public double nextDouble() throws NoSuchAlgorithmException, InvalidKeyException {

        double result = 1;
        long tmp;
        long max = 0x7FFFFFFFFFFFFFFFL;

        while (result ==1.0){
            this.V = Random.hmacSha256(this.K, this.V);
            ByteBuffer buffer = ByteBuffer.wrap(this.V, 0, 8);
            tmp = buffer.getLong();
            tmp = tmp & max;
            result = ((double) tmp) / ((double) max);
        }

        return result;
    }

    public static  byte[] hmacSha256(byte[] key, byte[] data) throws InvalidKeyException, NoSuchAlgorithmException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "HmacSHA256");
        Mac hasher = Mac.getInstance("HmacSHA256");
        hasher.init(secretKeySpec);
        return hasher.doFinal(data);

    }
}
