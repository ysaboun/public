package pf.demo.keyboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeyboardApplication {
	public static void main(String[] args) {
		SpringApplication.run(KeyboardApplication.class, args);
	}
}
