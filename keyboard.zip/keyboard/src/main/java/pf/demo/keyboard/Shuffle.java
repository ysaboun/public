package pf.demo.keyboard;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Shuffle {
    public static void shuffle(byte[] seed, int[] array) throws NoSuchAlgorithmException, InvalidKeyException {
        Random rand = new Random(seed);
        int r, tmp;

        for(int i=0; i<array.length; i++){
            //random positions
            r = (int) Math.floor(rand.nextDouble() * ((double) array.length));

            //swap value
            tmp = array[i];
            array[i] = array[r];
            array[r]= tmp;
        }
    }
}
